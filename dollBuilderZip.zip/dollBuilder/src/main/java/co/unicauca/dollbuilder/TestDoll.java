/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicauca.dollbuilder;
import java.util.Scanner;
/**
 *
 * @author ahurtado
 */
public class TestDoll {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // creamos el objeto Scanner para poder capturar el dato de pantalla
        Scanner lectura = new Scanner(System.in);
        // TODO code application logic here
        /*DollBuilder myBuilder = new RagDollBuilder();
        DollDirector director = new DollDirector(myBuilder);
        director.dollConstruct();
        Doll myDoll = myBuilder.getDoll();
        System.out.print(myDoll.toString());
        */
        System.out.println("Seleccione que tipo de muñeca quiere construir 1. Trapo 2. Plastico");
        String selección = lectura.nextLine();
        if ( selección == "1"){
            DollBuilder myBuilder = new RagDollBuilder();
            DollDirector director = new DollDirector(myBuilder);
            director.dollConstruct();
            Doll myDoll = myBuilder.getDoll();
            System.out.print(myDoll.toString());
        }
        else {
            DollBuilder myBuilder = new PlasticDollBuilder();
            DollDirector director = new DollDirector(myBuilder);
            director.dollConstruct();
            Doll myDoll = myBuilder.getDoll();
            System.out.print(myDoll.toString());
              
        }
    }
    
}

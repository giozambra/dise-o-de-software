/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicauca.dollbuilder;

/**
 *
 * @author ahurtado
 */
public class DollDirector {
    
    private DollBuilder myDollBuilder;

    public DollDirector(DollBuilder myDollBuilder) {
        this.myDollBuilder = myDollBuilder;
    }
  
    public Doll dollConstruct(){
        myDollBuilder.buildBody();
        for (int i=0;i<2;i++){
            myDollBuilder.buildHand();
        }
        for (int i=0;i<2;i++){
            myDollBuilder.buildLeg();
        }
        myDollBuilder.buildHead();
        return myDollBuilder.getDoll();
    }
    
    
    
}

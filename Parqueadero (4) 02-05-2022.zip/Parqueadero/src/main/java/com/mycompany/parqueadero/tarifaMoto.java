/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueadero;



/**
 *
 * @author u1801
 */
public class tarifaMoto extends Tarifa {
    private double totalh;
    
    
    public tarifaMoto(double totalh){
        this.totalh = totalh;
    }
    
    public double calcular() {
        double result = 0;
       if (totalh<= 3) {
            result += 3000;
       } else {
           result = totalh* 1000;
        }
         System.out.println ( " el resultado es"+result);
       return result;
    }

    

}

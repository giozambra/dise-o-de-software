/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicauca.dollbuilder;

/**
 *
 * @author ahurtado
 */
class Doll {

    public Doll() {
        body = "";
        legl = "";
        legr = "";
        handl = "";
        handr = "";
        head = "";
    }
    
    private String body;
    private String legl;
    private String legr;
    private String handl;
    private String handr;
    private String head;

    /**
     * @return the body
     */
    public String getBody() {
        return body;
    }

    /**
     * @param body the body to set
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * @return the legl
     */
    public String getLegl() {
        return legl;
    }

    /**
     * @param legl the legl to set
     */
    public void setLegl(String legl) {
        this.legl = legl;
    }

    /**
     * @return the legr
     */
    public String getLegr() {
        return legr;
    }

    /**
     * @param legr the legr to set
     */
    public void setLegr(String legr) {
        this.legr = legr;
    }

    /**
     * @return the handl
     */
    public String getHandl() {
        return handl;
    }

    /**
     * @param handl the handl to set
     */
    public void setHandl(String handl) {
        this.handl = handl;
    }

    /**
     * @return the handr
     */
    public String getHandr() {
        return handr;
    }

    /**
     * @param handr the handr to set
     */
    public void setHandr(String handr) {
        this.handr = handr;
    }

    /**
     * @return the head
     */
    public String getHead() {
        return head;
    }

    /**
     * @param head the head to set
     */
    public void setHead(String head) {
        this.head = head;
    }
    
    @Override
    public String toString(){
        return ""+ body +" " + legl + " " + legr + " " + handl + " " + handr + " " + head ;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicauca.dollbuilder;

/**
 *
 * @author ahurtado
 */
public class PlasticDollBuilder extends DollBuilder {
    
    private Doll myDoll;

    @Override
    public void buildBody() {
        myDoll = new Doll();
        myDoll.setBody("Cuerpo es plástico");
    }

    @Override
    public Doll getDoll() {
        return myDoll;
    }

    @Override
    public void buildHand() {
        if (myDoll.getHandl()=="")
            myDoll.setHandl("Mano izquierda de plástico");
        else 
            myDoll.setHandr("Mano derecha de plástico");
    }

    @Override
    public void buildLeg() {
           if (myDoll.getLegl()=="")
            myDoll.setLegl("Pie izquierdo de plástico");
        else 
           myDoll.setLegr("Pie derecho de plástico");
    }

    @Override
    public void buildHead() {
        myDoll.setHead("Cabeza de plástico");
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.parqueadero;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author u1801
 */

public class Parqueadero {
    
    public static void main(String[] args) {
        Scanner lectura = new Scanner (System.in);
        //leyendo la hora de entrada
        System.out.println("Ingrese hora de entrada: ");
        String hora = lectura.nextLine();
        String formato = "yyyy-MM-dd HH:mm:ss";
        DateTimeFormatter formateador = DateTimeFormatter.ofPattern(formato);
        LocalDateTime horainicial = LocalDateTime.parse(hora,formateador);
        
        System.out.println("Ingrese hora de salida: ");
        hora = lectura.nextLine();
        LocalDateTime horafinal = LocalDateTime.parse(hora,formateador);
        
        
        long diff = horafinal.getHour()-horainicial.getHour();
        long diffmin=horafinal.getMinute()-horainicial.getMinute();
        System.out.println("The difference in horas is : "+diff);
        System.out.println("The difference in minutos is : "+diffmin);
    }
}

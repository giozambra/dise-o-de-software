/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueadero;
import java.util.Date;
import java.util.concurrent.TimeUnit;


/**
 *
 * @author u1801
 */
public abstract class Tarifa {
    /*Date horainicial = new Date();
    Date horafinal = new Date();
    //public int horainicial;
    //public int horafinal;
    public long totalhoras;
    public double valorTotal;
    public int tipoVehiculo;
    public abstract double calculartarifa(double tiempototal);*/
    public abstract double calcular();
    public Tarifa(){
        
    }/*
    public Date gethorainicial() {
        return horainicial;
    }
    public Date gethorafinal() {
        return horafinal;
    }
    public int gettipoVehiculo() {
        return tipoVehiculo;
    }
    public long gettotalhoras() {
        return totalhoras;
    }
    public double getvalorTotal() {
        return valorTotal;
    }
    
    public void settotalhoras(int totalhoras) {
        this.totalhoras = totalhoras;
    }
    public void sethorainicial(Date horainicial) {
        this.horainicial = horainicial;
    }
    public void sethorafinal(Date horafinal) {
        this.horafinal = horafinal;
    }
    public void setvalorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
    public void settipoVehiculo(int tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }
    */
    
}

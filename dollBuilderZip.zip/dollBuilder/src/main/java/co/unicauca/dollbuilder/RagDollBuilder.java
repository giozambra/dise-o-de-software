/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.unicauca.dollbuilder;

/**
 *
 * @author u1801
 */
public class RagDollBuilder extends DollBuilder {

    private Doll myDoll;
    
    @Override
    public void buildBody() {
        myDoll=new Doll();
        myDoll.setBody("Cuerpo de trapo");
    }

    @Override
    public Doll getDoll() {
        return myDoll;
    }

    @Override
    public void buildHand() {
        if (myDoll.getHandl()=="")
            myDoll.setHandl("Mano izquierda de trapo");
        else 
            myDoll.setHandr("Mano derecha de trapo");
    }

    @Override
    public void buildLeg() {
        if (myDoll.getLegl()=="")
            myDoll.setLegl("Pie izquierdo de trapo");
        else 
           myDoll.setLegr("Pie derecho de trapo");
    }

    @Override
    public void buildHead() {
        myDoll.setHead("Cabeza de trapo");
    }
    
}
